# DISPLAY THE OUTPUT
print("New Python file")
